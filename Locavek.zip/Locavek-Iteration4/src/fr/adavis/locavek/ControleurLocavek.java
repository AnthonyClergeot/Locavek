package fr.adavis.locavek;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.* ;

import javax.swing.*;

/** Contrôleur associé à la vue principale de l'application
 * @author xilim
 *
 */
public class ControleurLocavek implements ActionListener {

	private VueLocavek vue ;
	
	/** Constructeur
	 * @param vue La vue principale de l'application
	 */
	public ControleurLocavek(VueLocavek vue) {
		super();
		System.out.println("ControleurLocavek::ControleurLocavek()") ;
		this.vue = vue ;
		this.enregistrerEcouteur();
	}
	
	public VueLocavek getVuePrincipale() {
		return this.vue ;
	}

	public void setVuePrincipales(VueLocavek vue) {
		this.vue = vue ;
	}
	
	/** Enregistrer le contrôleur comme écouteur des items de menu
	 * 
	 */
	private void enregistrerEcouteur(){
		System.out.println("ControleurLocavek::enregistrerEcouteur()") ;
		// Votre code ici
		this.vue.getItemQuitter().addActionListener(this) ;
		this.vue.getItemConnecter().addActionListener(this) ;
		this.vue.getItemDeconnecter().addActionListener(this) ;
		this.vue.getItemEnregistrerClient().addActionListener(this) ;
		this.vue.getItemEnregistrerLocation().addActionListener(this) ;
		this.vue.getItemVisualiserClients().addActionListener(this) ;
		this.vue.getItemVisualiserLocations().addActionListener(this) ;
		this.vue.getItemVisualiserVehicules().addActionListener(this) ;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		System.out.println("ControleurLocavek::actionPerformed()") ;
		Object sourceEvt = e.getSource() ;
		
		if(e.getSource() == this.vue.getItemQuitter()) {
			int choix = JOptionPane.showConfirmDialog(vue, "Voulez vous vraiment fermer l'application ?", "Quitter", 0) ;
			if(choix == 0) {
				System.exit(0) ;
			}	
		}
		
		if(e.getSource() == this.vue.getItemConnecter()) {
			VueAuthentification authentification = new VueAuthentification(this.vue) ;
			EtatTentativeConnexion etat = authentification.getEtatTentativeConnexion() ;
			if(etat == EtatTentativeConnexion.OK) {
				this.vue.setMenusConnecte();
			}
		}
		
		if(e.getSource() == this.vue.getItemDeconnecter()) {
			int choix = JOptionPane.showConfirmDialog(vue, "Voulez vous vraiment vous deconnecter ?", "Deconnexion", 0) ;
			if(choix == 0) {
				this.vue.setMenusDeconnecte() ;
			}
			this.vue.changerVue("Accueil") ;
		}
		
		if(e.getSource() == this.vue.getItemEnregistrerClient()) {
			VueNouveauClient client = new VueNouveauClient(this.vue) ;
			vue.getListeClients().getModeleTabClients().actualiser() ;
		}
		
		if(e.getSource() == this.vue.getItemEnregistrerLocation()) {
			VueNouvelleLocation client = new VueNouvelleLocation(this.vue) ;
			vue.getListeLocations().getModeleTabLocations().actualiser() ;
		}
		
		if(e.getSource() == this.vue.getItemVisualiserClients()) {
			this.vue.changerVue("ListeClients") ;
		}
		
		if(e.getSource() == this.vue.getItemVisualiserVehicules()) {
			this.vue.changerVue("ListeVehicules") ;
		}
		
		if(e.getSource() == this.vue.getItemVisualiserLocations()) {
			this.vue.changerVue("ListeLocations") ;
		}
		
	}
		
	
}
