package fr.adavis.locavek;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.* ;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;

/** Modèle de l'application
 * 
 * @author xilim
 *
 */
public class ModeleLocavek {
	
	private static ModeleLocavek modele = null;
	
	private List<Utilisateur> utilisateurs = new ArrayList<Utilisateur>() ;
	private List<Location> locations = new ArrayList<Location>() ;
	private List<Client> clients = new ArrayList<Client>() ;
	private List<Vehicule> vehicules = new ArrayList<Vehicule>() ;
	
	/** Constructeur
	 * 
	 */
	private ModeleLocavek(){
		super() ;
		System.out.println("ModeleLocavek::ModeleLocavek()") ;
		this.peupler() ;
	}
	
	/** Obtenir une unique instance du modèle
	 * @return Le modèle
	 */
	public static ModeleLocavek getModele(){
		System.out.println("ModeleLocavek::getModele()") ;
		if(modele == null){
			modele = new ModeleLocavek() ;
		}
		return modele ;
	}
	
	
	/** Peupler la base de données manipulée
	 * 
	 */
	private void peupler(){
		System.out.println("ModeleLocavek::peupler()") ;
		
		this.utilisateurs.add(new Utilisateur("ahecker","azerty")) ;
		this.utilisateurs.add(new Utilisateur("eprigent","azerty")) ;
		this.utilisateurs.add(new Utilisateur("jythomas","azerty")) ;
		this.utilisateurs.add(new Utilisateur("aalves","azerty")) ;
		this.utilisateurs.add(new Utilisateur("bba","azerty")) ;
		this.utilisateurs.add(new Utilisateur("rbouraoui","azerty")) ;
		this.utilisateurs.add(new Utilisateur("cchaudey","azerty")) ;
		this.utilisateurs.add(new Utilisateur("aclergeot","azerty")) ;
		this.utilisateurs.add(new Utilisateur("ygodefroy","azerty")) ;
		this.utilisateurs.add(new Utilisateur("vleguevel","azerty")) ;
		this.utilisateurs.add(new Utilisateur("mlebeau","azerty")) ;
		this.utilisateurs.add(new Utilisateur("blozach","azerty")) ;
		this.utilisateurs.add(new Utilisateur("gpequery","azerty")) ;
		this.utilisateurs.add(new Utilisateur("cperello","azerty")) ;
		this.utilisateurs.add(new Utilisateur("gwelle","azerty")) ;
		this.utilisateurs.add(new Utilisateur("aclergeot","azerty")) ;
		
//		this.vehicules.add(new Vehicule("AA-111-AA","Citroën C1",2014,1000)) ;
//		this.vehicules.add(new Vehicule("BB-222-BB","Citroën C2",2011,22000)) ;
//		this.vehicules.add(new Vehicule("CC-333-CC","Citroën C3",2012,3000)) ;
//		this.vehicules.add(new Vehicule("DD-444-DD","Citroën C4",2012,40000)) ;
//		this.vehicules.add(new Vehicule("EE-555-EE","Citroën C5",2011,100000)) ;
//		this.vehicules.add(new Vehicule("FF-666-FF","Citroën C2",2013,52000)) ;
//		this.vehicules.add(new Vehicule("GG-777-GG","Citroën C3",2013,48020)) ;
//		this.vehicules.add(new Vehicule("HH-888-HH","Citroën C4",2013,59230)) ;
//		this.vehicules.add(new Vehicule("II-999-II","Citroën C2",2012,70323)) ;
//		this.vehicules.add(new Vehicule("JJ-010-JJ","Citroën C4",2011,55827)) ;
//		this.vehicules.add(new Vehicule("KK-020-KK","Citroën C5",2014,1200, 3)) ;
		
		this.clients.add(new Client(1,"GENPRI","Erwan","0682492032")) ;
		this.clients.add(new Client(2,"KERREH","Armèle","0638678858")) ;
		this.clients.add(new Client(3,"TEFFON","Christophe","0627032673")) ;
		this.clients.add(new Client(5,"ARAUZO","Julien","0639607542")) ;
		this.clients.add(new Client(6,"MILLET","Antoine","0619264309")) ;
		this.clients.add(new Client(7,"KIENTZEL","Louis","0729443875")) ;
		this.clients.add(new Client(8,"BELHADJ","Taslim","0640908628")) ;
		this.clients.add(new Client(9,"BELLAICHE","Mikaël","0631784099")) ;
		this.clients.add(new Client(10,"BRIATTE","Guillaume","0628365347")) ;
		this.clients.add(new Client(11,"COESNOM","Florian","0696784358")) ;
		this.clients.add(new Client(12,"HURON","Kévin","0721011728")) ;
		this.clients.add(new Client(13,"JACQUIER","Nicolas","0606293623")) ;
		this.clients.add(new Client(14,"N'DIAYE","Mamadou","0630879007")) ;
		this.clients.add(new Client(15,"POIRIER","Nicolas","0657398079")) ;
		this.clients.add(new Client(16,"RAFINA","Dany","0638586890")) ;
		this.clients.add(new Client(17,"ROSCO","Steve","0620184981")) ;
		this.clients.add(new Client(18,"UZAN","Alexis","0667838291")) ;
		this.clients.add(new Client(19,"WELLE","Guillaume","0659023320")) ;
		
//		this.locations.add(new Location(1, this.getVehicule("AA-111-AA"), this.getClient(1), 
//				new DateFR(01, 9, 2015), new DateFR(02, 9, 2015), new DateFR(03, 9, 2015))) ;
//		this.locations.add(new Location(2, this.getVehicule("BB-222-BB"), this.getClient(2), 
//				new DateFR(03, 9, 2015), new DateFR(03, 9, 2015), new DateFR(03, 9, 2015))) ;
//		this.locations.add(new Location(3, this.getVehicule("BB-222-BB"), this.getClient(3), 
//				new DateFR(03, 9, 2015), new DateFR(05, 9, 2015), new DateFR(15, 9, 2015))) ;
//		this.ajouterLocation(this.getVehicule("CC-333-CC"), this.getClient(5), new DateFR(15, 10, 2015)) ;
		
	}
	
	/** Rechercher un utilisateur par son nom de connexion et son mot de passe
	 * 
	 * @param login Le nom de connexion de l'utilisateur
	 * @param mdp Le mot de passe de l'utilisateur
	 * @return L'utilisateur ou null si le nom de connexion et/ou le mot de passe sont incorrects
	 */
	public Utilisateur getUtilisateur(String login, String mdp){
		System.out.println("ModeleLocavek::getUtilisateur()") ;
		Utilisateur utilisateur = null ;
		int i = 0 ;
		while(i < this.utilisateurs.size() && utilisateur == null){
			if( this.utilisateurs.get(i).getLogin().equals(login) &&
					this.utilisateurs.get(i).getMdp().equals(mdp)){
				utilisateur = this.utilisateurs.get(i) ;
			}
			else {
				i = i + 1 ;
			}
		}
		return utilisateur ;
	}
	
	
	/** Obtenir la liste des locations
	 * 
	 * @return La liste des locations
	 * @throws SQLException 
	 */
//	public List<Location> getLocations(){
//		System.out.println("ModeleLocavek::getLocations()") ;
//		return this.locations ;
//	}
	
	public List<Location> getLocations() {
		System.out.println("ModeleLocavek::getLocations()") ;
		List<Location> lesLocations = new ArrayList<Location>() ;
		Map<Integer, Client> lesClients = new HashMap<Integer, Client>() ;
		Map<String, Vehicule> lesVehicules = new HashMap<String, Vehicule>() ;
		
		java.sql.Connection connexion = ConnexionBD.getConnexion() ;
		
		java.sql.Statement stmt;
		try {
			stmt = connexion.createStatement();
			
			String requete = "SELECT numLocation, depart, retourPrevu, retourEffectif, Location.numClient, "
					+ "Location.immatriculation, nom, prenom, mobile, modele, annee, compteur, situation "
					+ "FROM Location INNER JOIN Client "
					+ "ON Location.numClient = Client.numClient "
					+ "INNER JOIN Vehicule "
					+ "ON Location.immatriculation = Vehicule.immatriculation "; 		
			ResultSet resultat = stmt.executeQuery(requete) ;
			
			while(resultat.next()) {
				int numeroClient = resultat.getInt("Location.numClient") ;
				Client unClient = lesClients.get(new Integer(numeroClient)) ;
				if(unClient == null) {
					unClient = new Client() ;
					unClient.setNumero(resultat.getInt("Location.numClient")) ;
					unClient.setNom(resultat.getString("nom")) ;
					unClient.setPrenom(resultat.getString("prenom")) ;
					unClient.setMobile(resultat.getString("mobile")) ;
					lesClients.put(new Integer(numeroClient), unClient) ;
				}
				
				String immatriculation = resultat.getString("Location.immatriculation") ;
				Vehicule unVehicule = lesVehicules.get(immatriculation) ;
				if(unVehicule == null) {
					unVehicule = new Vehicule() ;
					unVehicule.setImmatriculation(resultat.getString("immatriculation")) ;
					unVehicule.setModele(resultat.getString("modele")) ;
					unVehicule.setAnnee(resultat.getInt("annee")) ;
					unVehicule.setCompteur(resultat.getInt("compteur")) ;
					unVehicule.setSituation(resultat.getInt("situation")) ;
					lesVehicules.put(immatriculation, unVehicule) ;
				}
				
				Location uneLocation = new Location() ;
				uneLocation.setNumero(resultat.getInt("numLocation")) ;
				uneLocation.setDateDepart(DateFR.parseString2(resultat.getString("depart"))) ;
				uneLocation.setDateRetourPrevue(DateFR.parseString2(resultat.getString("retourPrevu"))) ;
				if(resultat.getString("retourEffectif") != null) {
					uneLocation.setDateRetourEffective(DateFR.parseString2(resultat.getString("retourEffectif"))) ;
				}
				uneLocation.setClient(unClient) ;
				uneLocation.setVehicule(unVehicule) ;
				
			}
			
			resultat.close() ;
			stmt.close() ;
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return lesLocations ;
		
	}
	
	/** Obtenir la liste des clients
	 * 
	 * @return La liste des clients
	 */
//	public List<Client> getClients(){
//		System.out.println("ModeleLocavek::getClients()") ;
//		return this.clients ;
//	}
	
	public List<Client> getClients(){
		System.out.println("ModeleLocavek::getClients()") ;
		List<Client> lesClients = new ArrayList<Client>() ;
		
		java.sql.Connection connexion = ConnexionBD.getConnexion() ;
		
		try {
			
			java.sql.Statement stmt = connexion.createStatement() ;
			String requete = "SELECT numClient, nom, prenom, mobile FROM Client ;" ;
			ResultSet resultat = stmt.executeQuery(requete) ;
			
			while(resultat.next()) {
				Client unClient = new Client() ;
				unClient.setNumero(resultat.getInt("numClient")) ;
				unClient.setNom(resultat.getString("nom")) ;
				unClient.setPrenom(resultat.getString("prenom")) ;
				unClient.setMobile(resultat.getString("mobile")) ;
				lesClients.add(unClient) ;
			}
			
			resultat.close() ;
			stmt.close() ;
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return lesClients ;
		
	}
	
	/** Obtenir la liste des véhicules
	 * 
	 * @return La liste des véhicules
	 */
//	public List<Vehicule> getVehicules(){
//		System.out.println("ModeleLocavek::getVehicules()") ;
//		return this.vehicules ;
//	}
	
	public List<Vehicule> getVehicules(){
		System.out.println("ModeleLocavek::getVehicules()") ;
		List<Vehicule> lesVehicules = new ArrayList<Vehicule>() ;
		
		java.sql.Connection connexion = ConnexionBD.getConnexion() ;
		
		try {
			
			java.sql.Statement stmt = connexion.createStatement() ;
			String requete = "SELECT immatriculation, modele, annee, compteur, situation FROM Vehicule ;" ;
			ResultSet resultat = stmt.executeQuery(requete) ;
			
			while(resultat.next()) {
				Vehicule unVehicule = new Vehicule() ;
				unVehicule.setImmatriculation(resultat.getString("immatriculation")) ;
				unVehicule.setModele(resultat.getString("modele")) ;
				unVehicule.setAnnee(resultat.getInt("annee")) ;
				unVehicule.setCompteur(resultat.getInt("compteur")) ;
				unVehicule.setSituation(resultat.getInt("situation")) ;
				lesVehicules.add(unVehicule) ;
			}
			
			resultat.close() ;
			stmt.close() ;
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return lesVehicules ;
	}
	
	/** Enregistrer une nouvelle location
	 * @param vehicule Le véhicule
	 * @param client Le client
	 * @param dateRetourPrevue La date de retour prévue
	 */
	public void ajouterLocation(Vehicule vehicule, Client client, DateFR dateRetourPrevue){
		System.out.println("ModeleLocavek::ajouterLocation()") ;
		DateFR dateDepart = new DateFR() ;
		int numero = this.genererNumeroLocation() ;
		Location location = new Location(numero,vehicule,client,dateDepart,dateRetourPrevue) ;
		this.locations.add(location) ;
		vehicule.setSituation(Vehicule.LOUE);
	}
	
	/** Enregistrer un nouveau client
	 * 
	 * @param nom Le nom
	 * @param prenom Le prénom
	 * @param mobile Le numéro de mobile
	 */
	public void ajouterClient(String nom, String prenom, String mobile){
		System.out.println("ModeleLocavek::ajouterClient()") ;
		int numero = genererNumeroClient() ;
		this.clients.add(new Client(numero,nom,prenom,mobile)) ;
	}
	
	/** Générer un numéro unique de client
	 * 
	 * @return Le numéro de client
	 */
	private int genererNumeroClient(){
		System.out.println("ModeleLocavek::genererNumeroClient()") ;
		int numMax = 0 ;
		for(Client client : this.clients){
			if(client.getNumero() > numMax){
				numMax = client.getNumero() ;
			}
		}
		return numMax + 1 ;
	}
	
	/** Générer un numéro unique de location
	 * 
	 * @return Le numéro de location
	 */
	public int genererNumeroLocation(){
		System.out.println("ModeleLocavek::genererNumeroLocation()") ;
		int numMax = 0 ;
		for(Location location : this.locations){
			if(location.getNumero() > numMax){
				numMax = location.getNumero() ;
			}
		}
		return numMax + 1 ;
	}
	
	/** Rechercher un client par son numéro
	 * 
	 * @param numero Le numéro du client
	 * @return Le client ou null si le client n'est pas recensé
	 */
	public Client getClient(int numero){
		System.out.println("ModeleLocavek::getClient()") ;
		Client client = null ;
		int i = 0 ;
		while(i < this.clients.size() && client == null){
			if(this.clients.get(i).getNumero() == numero){
				client = this.clients.get(i) ;
			}
			else {
				i += 1 ;
			}
		}
		return client ;
	}
	
	/** Rechercher une location par son numéro
	 * 
	 * @param numero Le numéro de la location
	 * @return La location ou null si la location n'existe pas
	 */
	private Location getLocation(int numero){
		System.out.println("ModeleLocavek::getLocation()") ;
		Location location = null ;
		int i = 0 ;
		while(i < this.locations.size() && location == null){
			if(this.locations.get(i).getNumero() == numero){
				location = this.locations.get(i) ;
			}
			else {
				i += 1 ;
			}
		}
		return location ;
	}
	
	/** Rechercher un véhicule par son immatriculation
	 * 
	 * @param immatriculation L'immatriculation du véhicule
	 * @return Le véhicule ou null si le véhicule n'est pas recensé
	 */
	private Vehicule getVehicule(String immatriculation){
		System.out.println("ModeleLocavek::getVehicule()") ;
		Vehicule vehicule = null ;
		for(Vehicule unVehicule : this.vehicules){
			if(unVehicule.getImmatriculation().equals(immatriculation)){
				vehicule = unVehicule ;
			}
		}
		return vehicule ;
	}
	
	/** Obtenir la liste des locations en cours
	 * 
	 * @return La liste des locations en cours
	 */
	public List<Location> getLocationsEnCours(){
		System.out.println("ModeleLocavek::getLocationsEnCours()") ;
		List<Location> locationsEnCours = new ArrayList<Location>() ;
		for(Location location : this.locations){
			if(location.estEnCours()){
				locationsEnCours.add(location) ;
			}
		}
		return locationsEnCours ;
	}
	
	/** Obtenir la liste des véhicules disponibles
	 * 
	 * @return La liste des véhicules disponibles
	 */
	public List<Vehicule> getVehiculesDisponibles(){
		System.out.println("ModeleLocavek::getVehiculesDisponibles()") ;
		List<Vehicule> vehiculesDisponibles = new ArrayList<Vehicule>() ;
		for(Vehicule vehicule : this.vehicules){
			if(vehicule.estDisponible()){
				vehiculesDisponibles.add(vehicule) ;
			}
		}
		return vehiculesDisponibles ;
	}
	
	/** Supprimer une location
	 * 
	 * @param numero Le numéro de la location
	 * @return true si la suppression de la location s'est déroulée avec succès et false dans le cas contraire
	 */
	public boolean supprimerLocation(int numero){
		System.out.println("ModeleLocavek::supprimerLocation()") ;
		Location location = getLocation(numero) ;
		if(location != null){
			location.getVehicule().setSituation(Vehicule.DISPONIBLE) ;
			this.locations.remove(location) ;
			return true ;
		}
		else {
			return false ;
		}
	}
	
	/** Enregistrer le retour d'un véhicule
	 * 
	 * @param numeroLocation Le numéro de la location
	 * @param nombreKm Le nombre de kilomètres au compteur
	 * @return true si l'enregistrement s'est déroulé avec succès et false dans le cas contraire
	 */
	public boolean enregistrerRetourVehicule(int numeroLocation, int nombreKm){
		System.out.println("ModeleLocavek::enregistrerRetourVehicule()") ;
		Location location = getLocation(numeroLocation) ;
		if(location != null){
			location.setDateRetourEffective(new DateFR()) ;
			location.getVehicule().setSituation(Vehicule.DISPONIBLE) ;
			location.getVehicule().setCompteur(nombreKm) ;
			return true ;
		}
		else {
			return false ;
		}
	}
	
	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		System.out.println("ModeleLocations::toString()") ;
		return "MetierLocations [locations=" + locations + "]";
	}
	
}
