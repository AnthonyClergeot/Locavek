package fr.adavis.locavek;

import java.awt.Color;
import java.awt.Component;

import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;

public class RenduCelluleLocation extends DefaultTableCellRenderer {
	
	private static final long serialVersionUID = 1L;

	public RenduCelluleLocation(){
		super() ;
	}

	@Override
	public Component getTableCellRendererComponent(JTable table, Object value,
			boolean isSelected, boolean hasFocus, int row, int column) {
		
		
		DefaultTableCellRenderer composant = (DefaultTableCellRenderer) super.getTableCellRendererComponent(table, value, 
				isSelected, hasFocus,	row, column);
		Location location = ((ModeleListeLocations) table.getModel()).getLocation(row) ;
		
		if(location.estEnCours()) {
			composant.setBackground(new Color(249, 219, 115, 80)) ;
		}
		else if(location.estTerminee()) {
			composant.setBackground(new Color(237, 200, 200, 80)) ;
		}
		
		if(column == 0 || column == 3) {
			composant.setHorizontalAlignment(LEFT) ;
		}
		if(column == 1 || column == 2 || column == 4) {
			composant.setHorizontalAlignment(CENTER) ;
		}

		return composant ;
	}

}
