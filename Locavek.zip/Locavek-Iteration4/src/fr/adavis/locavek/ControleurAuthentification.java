package fr.adavis.locavek;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

/** Contrôleur dédié à la vue "Authentification"
 * @author xilim
 *
 */
public class ControleurAuthentification implements ActionListener, DocumentListener {
	
	private VueAuthentification vue ;
	
	// Votre code ici
	private ModeleLocavek modele = ModeleLocavek.getModele() ;
	
	private EtatTentativeConnexion etatTentativeConnexion = EtatTentativeConnexion.ABANDON ;
	
	/** Constructeur
	 * @param vue La vue associée
	 */
	public ControleurAuthentification(VueAuthentification vue){
		super() ;
		System.out.println("ControleurAuthentification::ControleurAuthentification()") ;
		this.vue = vue ;
		this.enregistrerEcouteur() ;
	}
	
	/** Enregistrer le contrôleur comme écouteur des deux boutons
	 * 
	 */
	private void enregistrerEcouteur(){
		System.out.println("ControleurAuthentification::enregistrerEcouteur()") ;
		// Votre code ici
		this.vue.getTfLogin().getDocument().addDocumentListener(this) ;
		this.vue.getPfMDP().getDocument().addDocumentListener(this) ;
		this.vue.getbConnecter().addActionListener(this) ;
		this.vue.getbAnnuler().addActionListener(this) ;
	}
	
	/** Obtenir le résultat de la tentative de connexion
	 * @return Résultat de la tentative de connexion
	 */
	public EtatTentativeConnexion getEtatTentativeConnexion(){
		System.out.println("ControleurAuthentification::getEtatTentativeConnexion()") ;
		return this.etatTentativeConnexion ;
	}
	
	@Override
	public void changedUpdate(DocumentEvent e) {
		System.out.println("ControleurAuthentification::changedUpdate()") ;
		repercuterSaisieChamps() ;
	}

	@Override
	public void insertUpdate(DocumentEvent e) {
		System.out.println("ControleurAuthentification::insertUpdate()") ;
		repercuterSaisieChamps() ;
	}

	@Override
	public void removeUpdate(DocumentEvent e) {
		System.out.println("ControleurAuthentification::removeUpdate()") ;
		repercuterSaisieChamps() ;
	}
	
	public void repercuterSaisieChamps(){
		System.out.println("ControleurNouvelleLocation::repercuterSaisieChamps()") ;
		String champLogin = this.vue.getTfLogin().getText() ;
		String champMdp = this.vue.getPfMDP().getText() ;
		
		boolean champsOk = false ;
		
		if(champLogin.isEmpty() || champMdp.isEmpty()) {
			champsOk = false ;
		}
		else {
			champsOk = true ;
		}
		
		if(champsOk){
			this.vue.getbConnecter().setEnabled(true) ;
		}
		else {
			this.vue.getbConnecter().setEnabled(false) ;
		}
	}

	/* (non-Javadoc)
	 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		System.out.println("ControleurAuthentification::actionPerformed()") ;
		Object sourceEvt = e.getSource() ;
		// Votre code ici
		if(e.getSource() == this.vue.getbAnnuler()) {
			etatTentativeConnexion = EtatTentativeConnexion.ABANDON ;
			this.vue.dispose() ;
		}
		
		if(e.getSource() == this.vue.getbConnecter()) {
			String login = this.vue.getTfLogin().getText() ;
			String mdp = this.vue.getPfMDP().getText() ;
			Utilisateur user = this.modele.getUtilisateur(login, mdp) ;
			if(user == null) {
				etatTentativeConnexion = EtatTentativeConnexion.ECHEC ;
				JOptionPane.showMessageDialog(vue, "Login ou mot de passe incorrects") ;
				this.vue.initialiser() ;
			}
			else {
				etatTentativeConnexion = EtatTentativeConnexion.OK ;
				JOptionPane.showMessageDialog(vue, "L'utilisateur " + login + " s'est connecté") ;
				this.vue.dispose() ;
			}
		}
	}
	
}
