package fr.adavis.locavek;

import java.util.List;

import javax.swing.JButton;
import javax.swing.table.AbstractTableModel;

public class ModeleListeLocations extends AbstractTableModel {
	
	private static final long serialVersionUID = 1L;
	
	private List<Location> locations = ModeleLocavek.getModele().getLocations() ;
	private final String[] entetes = {"Numéro","Date départ","Date retour","Client","Véhicule", "Retour"} ;
	private JButton bEnregistrer = new JButton() ;
	
	public ModeleListeLocations() {
		super() ;
		System.out.println("ModeleListeLocations::ModeleListeLocations()") ;
	}

	@Override
	public int getRowCount() {
		System.out.println("ModeleListeLocations::getRowCount()") ;
		return this.locations.size() ;
	}

	@Override
	public int getColumnCount() {
		System.out.println("ModeleListeLocations::getColumnCount()") ;
		return this.entetes.length ;
	}
	
	@Override
	public String getColumnName(int columnIndex) {
		System.out.println("ModeleListeLocations::getColumnName()") ;
		return this.entetes[columnIndex] ;
	}
	
	@Override
	public Class<?> getColumnClass(int columnIndex) {
		System.out.println("ModeleListeLocations::getColumnClass()") ;
		
		switch(columnIndex) {
		
			case 0 : 
				return int.class ;
			
			case 1 : 
				return DateFR.class ;
			
			case 2 : 
				return DateFR.class  ;
			
			case 3 : 
				return Client.class ;
				
			case 4 : 
				return Vehicule.class ;
				
			case 5 :
				return JButton.class ;
			
			default :
				return Object.class ;
				
		}
		
	}
	
	@Override
	public boolean isCellEditable(int rowIndex, int columnIndex) {
		System.out.println("ModeleListeLocations::isCellEditable("+rowIndex+","+columnIndex+")") ;
		if(columnIndex == 5 && this.locations.get(rowIndex).estEnCours() == true) {
			return true ;
		}
		else {
			return false ;
		}
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		System.out.println("ModeleListeLocations::getValueAt("+rowIndex+","+columnIndex+")") ;
		
		Object resultat = null ;
		
		switch(columnIndex) {
		
			case 0 : 
				resultat = new Integer(this.locations.get(rowIndex).getNumero()) ;
				break ;
			
			case 1 : 
				resultat = this.locations.get(rowIndex).getDateDepart() ;
				break ;
			
			case 2 : 
				resultat = this.locations.get(rowIndex).getDateRetourEffective() ;
				break ;
			
			case 3 : 
				resultat = this.locations.get(rowIndex).getClient() ;
				break ;
				
			case 4 : 
				resultat = this.locations.get(rowIndex).getVehicule() ;
				break ;
			
		}
		
		return resultat ;
		
	}
	
	public void actualiser(){
		System.out.println("ModeleListeLocations::actualiser()") ;
		this.fireTableDataChanged();
	}
	
	public Location getLocation(int indiceLigne){
		return this.locations.get(indiceLigne) ;
	}

}
