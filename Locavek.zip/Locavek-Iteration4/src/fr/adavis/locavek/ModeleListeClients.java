package fr.adavis.locavek;

import java.util.List;

import javax.swing.table.AbstractTableModel;

public class ModeleListeClients extends AbstractTableModel {

	private static final long serialVersionUID = 1L;
	
	private List<Client> clients = ModeleLocavek.getModele().getClients() ;
	private final String[] entetes = {"Numéro","Nom","Prénom","Mobile"} ;
	
	public ModeleListeClients() {
		super() ;
		System.out.println("ModeleListeClients::ModeleListeClients()") ;
	}

	@Override
	public int getRowCount() {
		System.out.println("ModeleListeClients::getRowCount()") ;
		return this.clients.size() ;
	}

	@Override
	public int getColumnCount() {
		System.out.println("ModeleListeClients::getColumnCount()") ;
		return this.entetes.length ;
	}
	
	@Override
	public String getColumnName(int columnIndex) {
		System.out.println("ModeleListeClients::getColumnName()") ;
		return this.entetes[columnIndex] ;
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		System.out.println("ModeleListeClients::getValueAt("+rowIndex+","+columnIndex+")") ;
		
		Object resultat = null ;
		
		switch(columnIndex) {
		
			case 0 : 
				resultat = new Integer(this.clients.get(rowIndex).getNumero()) ;
				break ;
			
			case 1 : 
				resultat = this.clients.get(rowIndex).getNom() ;
				break ;
			
			case 2 : 
				resultat = this.clients.get(rowIndex).getPrenom() ;
				break ;
			
			case 3 : 
				resultat = this.clients.get(rowIndex).getMobile() ;
				break ;
			
		}
		
		return resultat ;
	}
	
	public void actualiser(){
		System.out.println("ModeleListeClients::actualiser()") ;
		this.fireTableDataChanged();
	}

}
