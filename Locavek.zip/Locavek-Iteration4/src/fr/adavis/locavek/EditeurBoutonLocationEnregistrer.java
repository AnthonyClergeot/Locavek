package fr.adavis.locavek;

import java.awt.Component;

import javax.swing.DefaultCellEditor;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JTable;

public class EditeurBoutonLocationEnregistrer extends DefaultCellEditor {
	
	protected JButton bouton ;
	private boolean isPushed ;
	static JCheckBox checkBox = new JCheckBox() ;
	private ControleurBoutonLocationEnregistrer controleur ;
	
	public EditeurBoutonLocationEnregistrer(VueListeLocations vue) {
		super(checkBox) ;
		System.out.println("EditeurBoutonLocationEnregistrer::EditeurBoutonLocationEnregistrer()") ;
		bouton = new JButton() ;
		controleur = new ControleurBoutonLocationEnregistrer() ;
	}
	
	public Component getTableCellEditorComponent(JTable table, Object objet, boolean bool, int row, int column) {
		controleur.setRow(row) ;
		controleur.setColumn(column) ;
		controleur.setTable(table) ;
		bouton.setText("Enregistrer") ;
		
		return bouton ;
	}

}
