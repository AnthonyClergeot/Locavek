package fr.adavis.locavek;

import java.awt.Dimension;

import javax.swing.Box;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

/** Vue associée au cas d'utilisation "Visualiser la liste des clients"
 * @author xilim
 *
 */
public class VueListeClients extends JPanel {


	private static final long serialVersionUID = 1L;
	
	private ModeleListeClients modeleTabClients = new ModeleListeClients() ;
	private JTable tabClients ;
	private JLabel ListeClients = new JLabel("Liste des clients") ;
	
	/** Constructeur
	 * 
	 */
	public VueListeClients(){
		super() ;
		System.out.println("VueListeClients::VueListeClients()") ;
		this.creerInterfaceUtilisateur() ;
	}
	
	/** Agencer les composants graphiques
	 * 
	 */
	private void creerInterfaceUtilisateur(){
		System.out.println("VueListeClients::creerInterfaceUtilisateur()") ;
		Box boxPrincipale = Box.createVerticalBox() ;
		Box boxEtiquette = Box.createHorizontalBox() ;
		Box boxTableau = Box.createHorizontalBox() ;
		
		this.tabClients = new JTable(this.modeleTabClients) ;
		this.tabClients.setRowHeight(30) ;
		JScrollPane spClients = new JScrollPane(this.tabClients) ;
		spClients.setPreferredSize(new Dimension(1090 , 350)) ;
		
		boxTableau.add(spClients) ;
		boxEtiquette.add(ListeClients) ;
		boxPrincipale.add(boxEtiquette) ;
		boxPrincipale.add(boxTableau) ;
		
		this.add(boxPrincipale) ;
		
	}
	
	public JTable getTabClients() {
		return tabClients;
	}

	public ModeleListeClients getModeleTabClients() {
		return modeleTabClients;
	}

	
}
