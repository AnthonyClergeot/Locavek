package fr.adavis.locavek;

import java.awt.Dimension;

import javax.swing.Box;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class VueListeVehicules extends JPanel {

	private static final long serialVersionUID = 1L;
	
	private ModeleListeVehicules modeleTabVehicules = new ModeleListeVehicules()  ;
	private JTable tabVehicules ;
	private JLabel ListeVehicule = new JLabel("Liste des véhicules") ;
	private RenduCelluleVehicule rendu = new RenduCelluleVehicule() ;
	
	/** Constructeur
	 * 
	 */
	public VueListeVehicules(){
		super() ;
		System.out.println("VueListeVehicules::VueListeVehicules()") ;
		this.creerInterfaceUtilisateur() ;
	}
	
	/** Agencer les composants graphiques
	 * 
	 */
	private void creerInterfaceUtilisateur(){
		System.out.println("VueListeVehicules::creerInterfaceUtilisateur()") ;
		Box boxPrincipale = Box.createVerticalBox() ;
		Box boxEtiquette = Box.createHorizontalBox() ;
		Box boxTableau = Box.createHorizontalBox() ;
		
		this.tabVehicules = new JTable(this.modeleTabVehicules) ;
		this.tabVehicules.setRowHeight(30) ;
		this.tabVehicules.setDefaultRenderer(Object.class, rendu) ;
		JScrollPane spClients = new JScrollPane(this.tabVehicules) ;
		spClients.setPreferredSize(new Dimension(1090 , 350)) ;
		
		boxTableau.add(spClients) ;
		boxEtiquette.add(ListeVehicule) ;
		boxPrincipale.add(boxEtiquette) ;
		boxPrincipale.add(boxTableau) ;
		
		this.add(boxPrincipale) ;
		
	}
	
	public JTable getTabVehicules() {
		return tabVehicules;
	}

	public ModeleListeVehicules getModeleTabVehicules() {
		return modeleTabVehicules;
	}
	
}
