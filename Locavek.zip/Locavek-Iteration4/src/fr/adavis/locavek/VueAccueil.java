package fr.adavis.locavek;

import javax.swing.Box;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class VueAccueil extends JPanel {
	
	JLabel accueil = new JLabel("Accueil") ;
	
	public VueAccueil() {
		super();
		System.out.println("VueAccueil::VueAccueil()") ;
		this.creerInterfaceUtilisateur() ;
	}
	
	private void creerInterfaceUtilisateur() {
		System.out.println("VueAccueil::creerInterfaceUtilisateur()") ;
		Box boxPrincipale = Box.createVerticalBox() ;
		Box boxEtiquette = Box.createHorizontalBox() ;
		
		boxEtiquette.add(accueil) ;
		boxPrincipale.add(boxEtiquette) ;
		
		this.add(boxPrincipale) ;
		this.setVisible(true) ;
		
	}

}
