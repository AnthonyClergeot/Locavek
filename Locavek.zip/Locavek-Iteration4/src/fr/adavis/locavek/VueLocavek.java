package fr.adavis.locavek;

import java.awt.CardLayout;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

/** Vue principale de l'application
 * 
 * @author xilim
 *
 */
public class VueLocavek extends JFrame {
	
	private static final long serialVersionUID = 1L;
	
	private ControleurLocavek controleur ;
		
	private JMenuItem itemConnecter  = new JMenuItem("Se connecter") ;
	private JMenuItem itemDeconnecter  = new JMenuItem("Se déconnecter") ;
	private JMenuItem itemQuitter = new JMenuItem("Quitter") ;
	private JMenuItem itemVisualiserLocations = new JMenuItem("Liste des locations") ;
	private JMenuItem itemEnregistrerLocation = new JMenuItem("Nouvelle location") ;
	private JMenuItem itemVisualiserClients = new JMenuItem("Liste des clients") ;
	private JMenuItem itemEnregistrerClient = new JMenuItem("Nouveau client") ;
	private JMenuItem itemVisualiserVehicules = new JMenuItem("Liste des véhicules") ;
	
	private JMenu menuFichier = new JMenu("Fichier") ;
	private JMenu menuLocations = new JMenu("Locations") ;
	private JMenu menuVehicules = new JMenu("Véhicules") ;
	private JMenu menuClients = new JMenu("Clients") ;
	
	private CardLayout clPanneaux ;
	private Container conteneur ;
	private VueAccueil Accueil = new VueAccueil() ;
	private VueListeClients ListeClients = new VueListeClients() ;
	private VueListeVehicules ListeVehicules = new VueListeVehicules() ;
	private VueListeLocations ListeLocations = new VueListeLocations() ;

	/** Constructeur
	 * 
	 */
	public VueLocavek() {
		super();
		System.out.println("VuePrincipale::VuePrincipale()") ;
		
		this.setTitle("Locavek") ;
		this.setSize(1300,500) ; 
		this.setLocationRelativeTo(null) ;
		this.setDefaultCloseOperation(EXIT_ON_CLOSE) ;
		
		this.creerBarreMenus() ;
		this.setMenusDeconnecte();
		this.setVisible(true) ;
		
		this.controleur = new ControleurLocavek(this) ;
		
		clPanneaux = new CardLayout(5 , 5) ;
		conteneur = this.getContentPane() ;
		conteneur.setLayout(clPanneaux) ;
		
		conteneur.add(Accueil, "Accueil") ;
		conteneur.add(ListeClients, "ListeClients") ;
		conteneur.add(ListeVehicules, "ListeVehicules") ;
		conteneur.add(ListeLocations, "ListeLocations") ;
		
		clPanneaux.show(conteneur, "Accueil") ;
		
	}
	
	public ControleurLocavek getControleur() {
		return this.controleur;
	}

	public JMenuItem getItemConnecter() {
		return itemConnecter;
	}
	
	public JMenuItem getItemQuitter() {
		return itemQuitter;
	}

	public JMenuItem getItemVisualiserLocations() {
		return itemVisualiserLocations;
	}

	public JMenuItem getItemEnregistrerLocation() {
		return itemEnregistrerLocation;
	}

	public JMenuItem getItemVisualiserClients() {
		return itemVisualiserClients;
	}

	public JMenuItem getItemEnregistrerClient() {
		return itemEnregistrerClient;
	}

	public JMenuItem getItemVisualiserVehicules() {
		return itemVisualiserVehicules;
	}

	public JMenuItem getItemDeconnecter() {
		return itemDeconnecter;
	}
	
	public VueListeClients getListeClients() {
		return ListeClients;
	}

	public VueListeVehicules getListeVehicules() {
		return ListeVehicules;
	}

	public VueListeLocations getListeLocations() {
		return ListeLocations;
	}

	/** Positionner les menus et les items de menu pour l'état "Connecté"
	 * 
	 */
	public void setMenusConnecte(){
		System.out.println("VuePrincipale::setMenusConnecte()") ;
		this.itemConnecter.setEnabled(false) ;
		this.itemDeconnecter.setEnabled(true) ;
		this.menuLocations.setEnabled(true) ;
		this.menuClients.setEnabled(true) ;
		this.menuVehicules.setEnabled(true) ;
		
	}
	
	/** Positionner les menus et les items de menu pour l'état "Déconnecté"
	 * 
	 */
	public void setMenusDeconnecte(){
		System.out.println("VuePrincipale::setMenusDeconnecte()") ;
		this.itemConnecter.setEnabled(true) ;
		this.itemDeconnecter.setEnabled(false) ;
		this.menuLocations.setEnabled(false) ;
		this.menuClients.setEnabled(false) ;
		this.menuVehicules.setEnabled(false) ;
	
	}

	/** Créer la barre de menus
	 * 
	 */
	private void creerBarreMenus(){
		System.out.println("VuePrincipale::creerBarreMenus()") ;
		JMenuBar barreMenus = new JMenuBar() ;
		
		menuFichier.add(this.itemConnecter) ;
		menuFichier.add(this.itemDeconnecter) ;
		menuFichier.addSeparator() ;
		menuFichier.add(this.itemQuitter) ;

		menuLocations.add(this.itemVisualiserLocations) ;
		menuLocations.add(this.itemEnregistrerLocation) ;
		
		menuClients.add(this.itemVisualiserClients) ;
		menuClients.add(this.itemEnregistrerClient) ;
		
		menuVehicules.add(this.itemVisualiserVehicules) ;
		
		barreMenus.add(menuFichier) ;
		barreMenus.add(menuLocations) ;
		barreMenus.add(menuClients) ;
		barreMenus.add(menuVehicules) ;
		
		this.setJMenuBar(barreMenus) ;
		
	}
	
	public void changerVue(String panel) {
		System.out.println("VuePrincipale::changerVue()") ;
		clPanneaux.show(conteneur, panel) ;
	}

}
