package fr.adavis.locavek;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.JOptionPane;

/** Contrôleur associé à la vue "Enregistrer un nouveau client"
 * @author xilim
 *
 */
public class ControleurNouveauClient implements ActionListener {

	private VueNouveauClient vue ;
	
	private ModeleLocavek modele = ModeleLocavek.getModele() ;

	/** Constructeur
	 * @param vue La vue relative au cas d'utilisation "Enregistrer un nouveau client"
	 */
	public ControleurNouveauClient(VueNouveauClient vue) {
		super();
		System.out.println("ControleurNouveauClient::ControleurNouveauClient()") ;
		this.vue = vue ;
		this.enregistrerEcouteur();
	}

	/** Enregistrer le contrôleur comme écouteur des boutons
	 * 
	 */
	private void enregistrerEcouteur(){
		System.out.println("ControleurNouveauClient::enregistrerEcouteur()") ;
		// Votre code ici
		this.vue.getbEnregistrer().addActionListener(this) ;
		this.vue.getbAnnuler().addActionListener(this) ;
		
	}
	
	public VueNouveauClient getVue() {
		return vue;
	}

	public void setVue(VueNouveauClient vue) {
		this.vue = vue;
	}
	
	public Client getDernierClientEnregistre() {
		List<Client> clients = this.modele.getClients() ;
		Client clientTrouvee = null ;
		for(int i = 0 ; i < clients.size() ; i++) {
			clientTrouvee = clients.get(i) ;
		}
		return clientTrouvee ;
	}

	/* (non-Javadoc)
	 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		System.out.println("ControleurNouveauClient::actionPerformed()") ;
		Object sourceEvt = e.getSource() ;
		
		// Votre code ici
		if(e.getSource() == this.vue.getbAnnuler()) {
			this.vue.dispose() ;
		}
		
		if(e.getSource() == this.vue.getbEnregistrer()) {
			String nom = this.vue.getTfNom().getText() ;
			String prenom = this.vue.getTfPrenom().getText() ;
			String mobile = this.vue.getTfMobile().getText() ;
			this.modele.ajouterClient(nom, prenom, mobile) ;
			int numClient = getDernierClientEnregistre().getNumero() ;
			JOptionPane.showMessageDialog(vue, "Le client numéro : " + numClient + "\n" + nom + " " + prenom 
					+ "\n" + mobile + "\na bien été ajouté") ;
			this.vue.dispose() ;
		}
		
	}
	
}
