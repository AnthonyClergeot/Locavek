package fr.adavis.locavek;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.JOptionPane;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

/** Contrôleur dédié à la vue "Enregistrer une nouvelle location"
 * @author xilim
 *
 */
public class ControleurNouvelleLocation implements ActionListener, DocumentListener {

	private VueNouvelleLocation vue ;
	private ModeleLocavek modele = ModeleLocavek.getModele() ;
	
	/** Constructeur
	 * @param vue La vue relative au cas d'utilisation "Enregistrer une nouvelle location"
	 */
	public ControleurNouvelleLocation(VueNouvelleLocation vue) {
		super();
		System.out.println("ControleurNouvelleLocation::ControleurNouvelleLocation()") ;
		this.vue = vue ;
		this.enregistrerEcouteur() ;
	}

	public VueNouvelleLocation getVue() {
		return vue;
	}

	public void setVue(VueNouvelleLocation vue) {
		this.vue = vue;
	}

	/** Enregistrer le contrôleur comme écouteur des boutons et de la zone de saisie de la date de retour prévue
	 * 
	 */
	private void enregistrerEcouteur(){
		System.out.println("ControleurNouvelleLocation::enregistrerEcouteur()") ;
		this.vue.getTfDateRetourPrevue().getDocument().addDocumentListener(this) ;
		this.vue.getbEnregistrer().addActionListener(this) ;
		this.vue.getbAnnuler().addActionListener(this) ;
		
	}

	@Override
	public void insertUpdate(DocumentEvent e) {
		System.out.println("ControleurNouvelleLocation::insertUpdate()") ;
		// Votre code ici si nécessaire
		repercuterSaisieDate() ;
	}

	@Override
	public void removeUpdate(DocumentEvent e) {
		System.out.println("ControleurNouvelleLocation::removeUpdate()") ;
		// Votre code ici si nécessaire
		repercuterSaisieDate() ;
	}

	@Override
	public void changedUpdate(DocumentEvent e) {
		System.out.println("ControleurNouvelleLocation::changedUpdate()") ;
		// Votre code ici si nécessaire
		repercuterSaisieDate() ;
	}
	
	public Location getDerniereLocationEnregistree() {
		List<Location> locations = this.modele.getLocations() ;
		Location locationTrouvee = null ;
		for(int i = 0 ; i < locations.size() ; i++) {
			locationTrouvee = locations.get(i) ;
		}
		return locationTrouvee ;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		System.out.println("ControleurNouvelleLocation::actionPerformed()") ;
		Object sourceEvt = e.getSource() ;
		// Votre code ici
		if(e.getSource() == this.vue.getbAnnuler()) {
			this.vue.dispose() ;
		}
		
		if(e.getSource() == this.vue.getbEnregistrer()) {
			String client = this.vue.getCbClients().getSelectedItem().toString() ;
			String vehicule = this.vue.getCbVehicules().getSelectedItem().toString() ;
			String dateDebut = new DateFR().toString() ;
			String dateRetour = this.vue.getTfDateRetourPrevue().getText() ;
			Client clientSelectionne = (Client) this.vue.getCbClients().getSelectedItem() ;
			Vehicule vehiculeSelectionne = (Vehicule) this.vue.getCbVehicules().getSelectedItem() ;
			DateFR dateRetourPrevue = DateFR.parseString(dateRetour) ;
			this.modele.ajouterLocation(vehiculeSelectionne, clientSelectionne, dateRetourPrevue) ;
			int numLocation = getDerniereLocationEnregistree().getNumero() ;
			JOptionPane.showMessageDialog(vue, "Location : " + numLocation + "\nLe client : " + client + "\na reservé le véhicule : " + vehicule 
					+ "\ndu : " + dateDebut + " au " + dateRetour + " .") ;
			this.vue.dispose() ;
		}
		
	}
	
	/** Positionne l'état du bouton "Enregistrer" en fonction de la valeur saisie
	 * dans le champ relatif à la date de retour prévue
	 * 
	 */
	private void repercuterSaisieDate(){
		System.out.println("ControleurNouvelleLocation::repercuterSaisieDate()") ;
		String dateSaisie = this.vue.getTfDateRetourPrevue().getText() ;
		System.out.println(dateSaisie) ;
		DateFR aujourdhui = new DateFR() ;
		System.out.println(aujourdhui) ;
		
		
		boolean dateRetourOk = false ;
		
		if( DateFR.estDate(dateSaisie) ){
			DateFR dateRetour = DateFR.parseString(dateSaisie) ;
			System.out.println("\t" + dateRetour) ;
			if(dateRetour.estIdentique(aujourdhui) || dateRetour.estPosterieure(aujourdhui)){
				dateRetourOk = true ;
			}
		}
		
		if(dateRetourOk){
			this.vue.getbEnregistrer().setEnabled(true) ;
		}
		else {
			this.vue.getbEnregistrer().setEnabled(false) ;
		}
	}
	
	
}
