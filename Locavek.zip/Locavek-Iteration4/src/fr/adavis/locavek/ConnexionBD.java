package fr.adavis.locavek;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnexionBD {
	
	private String dbURL = "jdbc:mysql://localhost/locavek" ;
	private String user = "root" ;
	private String password = "azerty" ;
	
	private static Connection connexion = null ;
	
	public ConnexionBD() {
		try {
			
			Class.forName("com.mysql.jdbc.Driver").newInstance() ;
			
			connexion = DriverManager.getConnection(dbURL, user, password) ;
			
			System.out.println("OK" + connexion) ;
			
		} catch (InstantiationException | IllegalAccessException
				| ClassNotFoundException | SQLException e) {
			e.printStackTrace() ;
		}
	}
	
	public static Connection getConnexion() {
		if(connexion == null) {
			new ConnexionBD() ;
		}
		return connexion ;
	}

}
