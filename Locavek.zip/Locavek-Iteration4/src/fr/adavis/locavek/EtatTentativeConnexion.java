package fr.adavis.locavek;

/** Etats possibles d'une tentative de connexion
 * @author xilim
 *
 */
public enum EtatTentativeConnexion {
	OK, ECHEC, ABANDON ;
}
