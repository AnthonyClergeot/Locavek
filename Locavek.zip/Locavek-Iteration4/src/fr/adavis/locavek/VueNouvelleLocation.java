package fr.adavis.locavek;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.GregorianCalendar;
import java.util.List;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

/** Vue relative au cas d'utilisation "Enregistrer une nouvelle location"
 * 
 * @author xilim
 *
 */
public class VueNouvelleLocation extends JDialog {

	private static final long serialVersionUID = 1L;
	
	private ControleurNouvelleLocation controleur ;
	
	// Votre code ici
	private ModeleLocavek modele = ModeleLocavek.getModele() ;
	
	private JComboBox<Client> cbClients = new JComboBox<Client>() ;
	private JComboBox<Vehicule> cbVehicules = new JComboBox<Vehicule>() ;
	
	private JTextField tfDateRetourPrevue = new JTextField() ;
	
	private JButton bEnregistrer = new JButton("Enregistrer") ;
	private JButton bAnnuler = new JButton("Annuler") ;
	
	/** Constructeur
	 * @param vueParente La vue principale de l'application
	 */
	public VueNouvelleLocation(JFrame vueParente) {
		super(vueParente,"Nouvelle location",true);
		System.out.println("VueNouvelleLocation::VueNouvelleLocation()") ;
		this.creerInterfaceUtilisateur() ;
		this.controleur = new ControleurNouvelleLocation(this) ;
		this.initialiser();
		this.pack();
		this.setLocationRelativeTo(vueParente) ;
		this.setResizable(false) ;
		this.setVisible(true) ;
	}

	public JComboBox<Client> getCbClients() {
		return cbClients;
	}
	
	public JComboBox<Vehicule> getCbVehicules() {
		return cbVehicules;
	}

	public JTextField getTfDateRetourPrevue() {
		return tfDateRetourPrevue;
	}

	public JButton getbEnregistrer() {
		return bEnregistrer;
	}

	public JButton getbAnnuler() {
		return bAnnuler;
	}

	/** Créer l'interface utilisateur
	 * 
	 */
	private void creerInterfaceUtilisateur(){
		System.out.println("VueNouvelleLocation::creerInterfaceUtilisateur()") ;
		
		// Votre code ici
		Container conteneur = this.getContentPane() ;
		
		Box boxPrincipale = Box.createVerticalBox() ;
		Box boxClient = Box.createHorizontalBox() ;
		Box boxVehicule = Box.createHorizontalBox() ;
		Box boxDateRetour = Box.createHorizontalBox() ;
		Box boxLigne = Box.createHorizontalBox() ;
		Box boxActions = Box.createHorizontalBox() ;
		
		boxClient.add(Box.createHorizontalStrut(5)) ;
		boxClient.add(new JLabel("Client : ")) ;
		boxVehicule.add(Box.createHorizontalStrut(5)) ;
		boxVehicule.add(new JLabel("Véhicule : ")) ;
		boxDateRetour.add(Box.createHorizontalStrut(5)) ;
		boxDateRetour.add(new JLabel("Date de retour : ")) ;
		
		boxClient.add(Box.createHorizontalStrut(19)) ;
		boxClient.add(this.cbClients) ;
		boxVehicule.add(this.cbVehicules) ;
		boxDateRetour.add(this.tfDateRetourPrevue) ;
		
		boxLigne.add(Box.createHorizontalStrut(5)) ;
		boxLigne.add(new JSeparator()) ;
		boxLigne.add(Box.createHorizontalStrut(5)) ;
		
		boxActions.add(Box.createHorizontalStrut(5)) ;
		boxActions.add(this.bEnregistrer) ;
		boxActions.add(Box.createHorizontalStrut(5)) ;
		boxActions.add(this.bAnnuler) ;
		boxActions.add(Box.createHorizontalStrut(5)) ;
		
		boxPrincipale.add(Box.createVerticalStrut(8)) ;
		boxPrincipale.add(boxClient) ;
		boxPrincipale.add(Box.createVerticalStrut(8)) ;
		boxPrincipale.add(boxVehicule) ;
		boxPrincipale.add(Box.createVerticalStrut(8)) ;
		boxPrincipale.add(boxDateRetour) ;
		boxPrincipale.add(Box.createVerticalStrut(10)) ;
		boxPrincipale.add(boxLigne) ;
		boxPrincipale.add(Box.createVerticalStrut(10)) ;
		boxPrincipale.add(boxActions) ;
		boxPrincipale.add(Box.createVerticalStrut(5)) ;
		
		conteneur.add(boxPrincipale) ;
		
		Dimension dimensionBouton = this.bEnregistrer.getPreferredSize() ;
		
		this.bAnnuler.setPreferredSize(dimensionBouton) ;
		this.bAnnuler.setMaximumSize(dimensionBouton) ;
		this.bAnnuler.setMinimumSize(dimensionBouton) ;
		
	}
	
	
	/** Initialiser les champs (liste des clients, liste des véhicules et date de retour prévue
	 * 
	 */
	private void initialiser(){
		System.out.println("VueNouvelleLocation::initialiser()") ;
		
		List<Client> clients = this.modele.getClients() ;
		for(int i = 0 ; i < clients.size() ; i++) {
			this.cbClients.addItem(clients.get(i)) ;
		}
		
		List<Vehicule> vehicules = this.modele.getVehiculesDisponibles() ;
		for(int i = 0 ; i < vehicules.size() ; i++) {
			this.cbVehicules.addItem(vehicules.get(i)) ;
		}
		
		DateFR date = new DateFR() ;
		this.tfDateRetourPrevue.setText(date.toString()) ;
		
	}
}
