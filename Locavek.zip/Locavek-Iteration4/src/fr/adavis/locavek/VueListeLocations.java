package fr.adavis.locavek;

import java.awt.Dimension;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class VueListeLocations extends JPanel {
	
	private static final long serialVersionUID = 1L;

	private ModeleListeLocations modeleTabLocations = new ModeleListeLocations()  ;
	private JTable tabLocations ;
	private JLabel ListeLocations = new JLabel("Liste des locations") ;
	private RenduCelluleLocation renduLocation = new RenduCelluleLocation() ;
	private RenduBoutonLocation renduBoutonLocation = new RenduBoutonLocation() ;
	private EditeurBoutonLocationEnregistrer editeurBoutonLocationEnregistrer = new EditeurBoutonLocationEnregistrer(this) ;
	
	public VueListeLocations(){
		super() ;
		System.out.println("VueListeLocations::VueListeLocations()") ;
		this.creerInterfaceUtilisateur() ;
		this.appliquerRendu() ;
	}
	
	private void creerInterfaceUtilisateur(){
		System.out.println("VueListeLocations::creerInterfaceUtilisateur()") ;
		Box boxPrincipale = Box.createVerticalBox() ;
		Box boxEtiquette = Box.createHorizontalBox() ;
		Box boxTableau = Box.createHorizontalBox() ;
		
		this.tabLocations = new JTable(this.modeleTabLocations) ;
		this.tabLocations.setRowHeight(30) ;
		JScrollPane spClients = new JScrollPane(this.tabLocations) ;
		spClients.setPreferredSize(new Dimension(1090 , 350)) ;
		
		boxTableau.add(spClients) ;
		boxEtiquette.add(ListeLocations) ;
		boxPrincipale.add(boxEtiquette) ;
		boxPrincipale.add(boxTableau) ;
		
		this.add(boxPrincipale) ;
		
	}
	
	public JTable getTabLocations() {
		return tabLocations;
	}

	public ModeleListeLocations getModeleTabLocations() {
		return modeleTabLocations;
	}
	
	public void appliquerRendu() {
		this.tabLocations.setDefaultRenderer(Object.class, renduLocation) ;
		if(tabLocations.getColumnClass(5) == JButton.class) {
			this.tabLocations.setDefaultRenderer(JButton.class, renduBoutonLocation) ;
		}
	}
	
	public void appliquerEditeur() {
		this.tabLocations.setDefaultEditor(Object.class, editeurBoutonLocationEnregistrer) ;
	}

}
