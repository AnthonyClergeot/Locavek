package fr.adavis.locavek;

import java.util.List;

import javax.swing.table.AbstractTableModel;

public class ModeleListeVehicules extends AbstractTableModel {

	private static final long serialVersionUID = 1L;
	
	private List<Vehicule> vehicules = ModeleLocavek.getModele().getVehicules() ;
	private final String[] entetes = {"Immatriculation","Modèle","Année","Compteur","Situation"} ;
	
	public ModeleListeVehicules() {
		super() ;
		System.out.println("ModeleListeVehicules::ModeleListeVehicules()") ;
	}

	@Override
	public int getRowCount() {
		System.out.println("ModeleListeVehicules::getRowCount()") ;
		return this.vehicules.size() ;
	}

	@Override
	public int getColumnCount() {
		System.out.println("ModeleListeVehicules::getColumnCount()") ;
		return this.entetes.length ;
	}
	
	@Override
	public String getColumnName(int columnIndex) {
		System.out.println("ModeleListeVehicules::getColumnName()") ;
		return this.entetes[columnIndex] ;
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		System.out.println("ModeleListeVehicules::getValueAt("+rowIndex+","+columnIndex+")") ;
		
		Object resultat = null ;
		
		switch(columnIndex) {
		
			case 0 : 
				resultat = this.vehicules.get(rowIndex).getImmatriculation() ;
				break ;
			
			case 1 : 
				resultat = this.vehicules.get(rowIndex).getModele() ;
				break ;
			
			case 2 : 
				resultat = this.vehicules.get(rowIndex).getAnnee() ;
				break ;
			
			case 3 : 
				resultat = this.vehicules.get(rowIndex).getCompteur() ;
				break ;
				
			case 4 : 
				resultat = this.vehicules.get(rowIndex).getSituation() ;
				if((Integer) resultat == 1) {
					resultat = "Disponible" ;
				}
				else if((Integer) resultat == 2) {
					resultat = "Loué" ;
				}
				else {
					resultat = "Immobilisé" ;
				}
				break ;
			
		}
		
		return resultat ;
	}
	
	public void actualiser(){
		System.out.println("ModeleListeVehicules::actualiser()") ;
		this.fireTableDataChanged();
	}
	
	public int getSituation(int indiceLigne){
		return vehicules.get(indiceLigne).getSituation() ;
	}

}
