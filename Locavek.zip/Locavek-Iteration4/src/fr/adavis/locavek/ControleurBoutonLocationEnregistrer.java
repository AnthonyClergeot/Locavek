package fr.adavis.locavek;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;
import javax.swing.JTable;

public class ControleurBoutonLocationEnregistrer implements ActionListener {

	private int row ;
	private int column ;
	private JTable table ;
	
	public ControleurBoutonLocationEnregistrer() {
		super() ;
		System.out.println("ControleurBoutonLocationEnregistrer::ControleurBoutonLocationEnregistrer()") ;
	}
	
	public int getRow() {
		return row;
	}

	public int getColumn() {
		return column;
	}

	public JTable getTable() {
		return table;
	}

	public void setRow(int row) {
		this.row = row ;
	}
	
	public void setColumn(int column) {
		this.column = column ;
	}
	
	public void setTable(JTable table) {
		this.table = table ;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		System.out.println("ControleurBoutonLocationEnregistrer::actionPerformed()") ;
		if(column == 5) {
			
		}
	}

}
